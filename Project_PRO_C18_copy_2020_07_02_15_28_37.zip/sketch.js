var monkey, monkeyImage;

var ground, groundImage

var banana, bananaImage;

var stone, stoneImage;

var jungle, jungleImage;

var obstaclesGroup

var foodGroup

var survivalTime;

function preload(){
  jungleImage = loadImage("jungle.jpg");
  player_running = loadAnimation("Monkey_01.png", "Monkey_02.png", "Monkey_03.png", "Monkey_04.png", "Monkey_05.png", "Monkey_06.png", "Monkey_07.png", "Monkey_08.png", "Monkey_09.png", "Monkey_10.png");
  
  bananaImage = loadImage("Banana.png");
  stoneImage = loadImage("stone.png");
}


function setup() {
  
  monkey = createSprite(100, 340, 20, 50);
  monkey.addAnimation(monkeyImage);
  monkey.scale = 0.1
  
  ground = createSprite(400, 350, 800, 10);
  ground.addImage("ground", groundImage);
  ground.velocityX = -4;
  ground.x = ground.width/2;
  
  survivalTime = 0;
  
  obstaclesGroup = createGroup();
  foodGroup = createGroup();
  
}

function draw() {
  
  background(255);
  
  monkey.collide(ground);
  
  
  if (keyDown("space")){
    monkey.velocityY = -12;
  }
  
  ground.velocityX = -6; 
  
  if (ground.x < 0){
    ground.x = ground.width/2;
  }
  
  spawnFood();
  
  spawnObstacles();
  
  monkey.velocityY = monkey.velocityY + 2;
  
  stroke("black");
  textSize(20);
  fill("black")
  survivalTime = Math.ceil(frameCount/frameRate());
  text("Survival Time:" + survivalTime, 100, 500);
  
  drawSprites();
}

function spawnFood(){
  if (World.frameCount % 80 === 0){
    banana = createSprite(400, randomNumber(180, 220), 20, 20);
    banana.setAnimation("Banana");
    banana.scale = 0.05;
    banana.velocityX = -6;
    
    banana.lifetime = -1;
    
    foodGroup.add(banana);
  }
}

function spawnObstacles(){
  if (World.frameCount % 60 === 0&&World.frameCount>300)
  {
    var stone = createSprite(400, 310, 20, 20);
    stone.setAnimation("Stone");
    stone.scale = 0.2;
    stone.velocityX = -6;
    
    stone.lifetime = -1;
    
    obstaclesGroup.add(stone);
  }
}